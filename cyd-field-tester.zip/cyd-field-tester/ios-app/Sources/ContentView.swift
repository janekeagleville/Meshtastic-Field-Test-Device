import SwiftUI

struct ContentView: View {
    @StateObject private var t = Tester()
    @State private var selected: UInt32? = nil
    @State private var showConnect = false
    @State private var showLogs = false
    @State private var splash = true

    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                if let id = selected, (t.nodes[id]?.count ?? 0) > 0 {
                    DetailView(t: t, id: id)
                } else {
                    NodeList(t: t, selected: $selected, showConnect: $showConnect)
                }
                navBar
            }
            if splash { SplashView().transition(.opacity).zIndex(2) }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showConnect) { ConnectView(t: t, show: $showConnect) }
        .sheet(isPresented: $showLogs) { LogsView(t: t) }
        .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { withAnimation(.easeOut(duration: 0.5)) { splash = false } } }
    }

    private var header: some View {
        HStack(spacing: 8) {
            Circle().fill(t.alive ? Theme.green : t.link == .idle ? Theme.red : Theme.amber).frame(width: 10, height: 10)
            (Text("LoRaWAN ").foregroundColor(.white) + Text("Field Test Kit").foregroundColor(Theme.turq))
                .font(.system(size: 17, weight: .bold))
            Spacer()
            Text(t.deviceName.isEmpty ? "no node" : t.deviceName).font(.system(size: 12)).foregroundStyle(Theme.dim).lineLimit(1)
        }
        .padding(.horizontal, 16).padding(.vertical, 10).background(Theme.hdr)
        .contentShape(Rectangle()).onTapGesture { showConnect = true }
    }

    private var navBar: some View {
        VStack(spacing: 6) {
            if !t.message.isEmpty { Text(t.message).font(.system(size: 12, weight: .semibold)).foregroundStyle(Theme.amber) }
            HStack(spacing: 10) {
                BarButton(title: selected == nil ? "CONNECT" : "LIST") { if selected == nil { showConnect = true } else { selected = nil } }
                if t.logging {
                    BarButton(title: "STOP \(t.written)", color: Theme.red, bg: Theme.badBg) { t.stopLog() }
                } else {
                    BarButton(title: "LOG") { t.toggleLog(node: selected) }
                }
                BarButton(title: "FILES") { showLogs = true }
            }
        }
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 8).background(Theme.hdr)
        .overlay(alignment: .top) { Rectangle().fill(Theme.line).frame(height: 1) }
    }
}

struct NodeList: View {
    @ObservedObject var t: Tester
    @Binding var selected: UInt32?
    @Binding var showConnect: Bool

    var body: some View {
        let list = t.sorted
        ScrollView {
            LazyVStack(spacing: 8) {
                if list.isEmpty {
                    Panel {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(title).font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                            Text("Frames: \(t.frames)   Errors: \(t.parseErrors)").font(.system(size: 13)).foregroundStyle(Theme.turq)
                            Text(hint).font(.system(size: 13)).foregroundStyle(Theme.amber)
                        }
                    }.onTapGesture { showConnect = true }
                } else {
                    HStack {
                        Caption("NODE"); Spacer(); Caption("RSSI dBm").frame(width: 84); Caption("SNR dB").frame(width: 68); Caption("AGE").frame(width: 48, alignment: .trailing)
                    }.padding(.horizontal, 12)
                    ForEach(list) { n in
                        Panel {
                            HStack(spacing: 8) {
                                Circle().fill(n.quality.color).frame(width: 9, height: 9)
                                Text(n.title).font(.system(size: 16, weight: .semibold)).foregroundStyle(.white).lineLimit(1)
                                Spacer(minLength: 4)
                                HStack(alignment: .lastTextBaseline, spacing: 2) { Text("\(n.rssi)").font(.system(size: 16, weight: .bold)).foregroundStyle(n.quality.color); Text("dBm").font(.system(size: 10)).foregroundStyle(Theme.dim) }.frame(width: 84)
                                HStack(alignment: .lastTextBaseline, spacing: 2) { Text(String(format: "%.1f", n.snr)).font(.system(size: 16)).foregroundStyle(Theme.turq); Text("dB").font(.system(size: 10)).foregroundStyle(Theme.dim) }.frame(width: 68)
                                Text(age(n.last)).font(.system(size: 14)).foregroundStyle(Theme.dim).frame(width: 48, alignment: .trailing)
                            }
                        }.onTapGesture { selected = n.id }
                    }
                }
            }.padding(.horizontal, 16).padding(.top, 10)
        }
    }

    private func age(_ d: Date) -> String {
        let s = Int(max(0, t.now.timeIntervalSince(d)))
        return s < 120 ? "\(s)s" : s < 7200 ? "\(s / 60)m" : "\(s / 3600)h"
    }
    private var title: String {
        switch t.link {
        case .idle: return "Not connected to a node"
        case .scanning: return "Scanning for BLE nodes…"
        case .connecting, .discovering: return "Connecting…"
        case .configuring: return "Downloading configuration…"
        case .ready: return "Waiting for packets from mesh nodes…"
        }
    }
    private var hint: String {
        if t.bluetoothState == .poweredOff { return "Turn on Bluetooth on this phone." }
        if t.bluetoothState == .unauthorized { return "Allow Bluetooth access for this app in iOS Settings." }
        switch t.link {
        case .idle: return "Tap to select a node (e.g. LilyGo T-Echo)."
        case .ready: return "Connected (API OK). Disconnect the official Meshtastic app: the node accepts only one BLE client."
        default: return "On first connection enter the PIN shown on the node screen (default 123456)."
        }
    }
}

struct SplashView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Theme.rgb(0, 60, 40), Theme.rgb(0, 16, 10)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            VStack(spacing: 10) {
                Text("LoRaWAN").font(.system(size: 52, weight: .heavy)).foregroundStyle(.white)
                Rectangle().fill(Theme.turq.opacity(0.8)).frame(width: 220, height: 1)
                Text("FIELD TEST KIT").font(.system(size: 22, weight: .bold)).tracking(3).foregroundStyle(Theme.turq)
            }
        }
    }
}
