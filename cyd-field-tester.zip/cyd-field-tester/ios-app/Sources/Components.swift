import SwiftUI

struct Panel<Content: View>: View {
    var tint: Color = Theme.panel
    let content: Content
    init(tint: Color = Theme.panel, @ViewBuilder content: () -> Content) { self.tint = tint; self.content = content() }
    var body: some View {
        content.padding(10).frame(maxWidth: .infinity, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 12).fill(tint))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.line.opacity(0.35), lineWidth: 1))
    }
}

struct Caption: View {
    let t: String
    init(_ t: String) { self.t = t }
    var body: some View { Text(t).font(.system(size: 11, weight: .semibold)).tracking(1).foregroundStyle(Theme.dim) }
}

struct QualityChip: View {
    let q: Quality
    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(q.color).frame(width: 7, height: 7)
            Text(q.text).font(.system(size: 12, weight: .bold)).foregroundStyle(q.color)
        }
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(Capsule().fill(q.bg)).overlay(Capsule().stroke(q.color, lineWidth: 1))
    }
}

/// Semicircular RSSI gauge with a red → amber → green → turquoise gradient.
struct Arc: Shape {
    var fraction: Double
    var animatableData: Double { get { fraction } set { fraction = newValue } }
    func path(in r: CGRect) -> Path {
        var p = Path()
        let c = CGPoint(x: r.midX, y: r.maxY), rad = min(r.width / 2, r.height)
        p.addArc(center: c, radius: rad, startAngle: .degrees(180), endAngle: .degrees(180 + 180 * fraction), clockwise: false)
        return p
    }
}

struct Gauge: View {
    let rssi: Int
    var body: some View {
        let f = min(max(Double(rssi - Cfg.gaugeMin) / Double(Cfg.gaugeMax - Cfg.gaugeMin), 0), 1)
        GeometryReader { g in
            let rad = min(g.size.width / 2 - 12, g.size.height - 12)
            ZStack {
                Arc(fraction: 1).stroke(Theme.track, style: StrokeStyle(lineWidth: 16, lineCap: .round))
                Arc(fraction: f)
                    .stroke(AngularGradient(gradient: Theme.gradient, center: UnitPoint(x: 0.5, y: 1), startAngle: .degrees(180), endAngle: .degrees(360)),
                            style: StrokeStyle(lineWidth: 16, lineCap: .round))
                    .animation(.easeOut(duration: 0.4), value: f)
            }
            .frame(width: rad * 2, height: rad)
            .position(x: g.size.width / 2, y: g.size.height - rad / 2 - 6)
            VStack(spacing: 0) {
                Text("\(rssi)").font(.system(size: 44, weight: .bold, design: .rounded)).foregroundStyle(.white)
                Text("dBm").font(.system(size: 13, weight: .semibold)).foregroundStyle(Theme.turq)
            }.position(x: g.size.width / 2, y: g.size.height - 40)
            HStack { Text("\(Cfg.gaugeMin)"); Spacer(); Text("\(Cfg.gaugeMax)") }
                .font(.system(size: 11)).foregroundStyle(Theme.dim)
                .padding(.horizontal, 4).frame(width: rad * 2 + 16).position(x: g.size.width / 2, y: g.size.height + 2)
        }
    }
}

struct BarMeter: View {
    var fraction: Double; var color: Color
    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(Theme.track)
                Capsule().fill(color).frame(width: max(4, g.size.width * min(max(fraction, 0), 1)))
            }
        }.frame(height: 6)
    }
}

struct HopDots: View {
    let hops: Int?
    var body: some View {
        let lit = hops.map { min($0, Cfg.hopMax) } ?? 0
        HStack(spacing: 0) {
            ForEach(0..<Cfg.hopMax, id: \.self) { i in
                Circle().fill(i < lit ? Theme.turq : Theme.track)
                    .overlay(Circle().stroke(i < lit ? Theme.turq : Theme.line, lineWidth: 1)).frame(width: 11, height: 11)
                if i < Cfg.hopMax - 1 { Rectangle().fill(i < lit - 1 ? Theme.turq : Theme.line).frame(height: 2) }
            }
        }
    }
}

struct BarButton: View {
    let title: String; var color = Theme.turq; var bg = Theme.okBg; let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title).font(.system(size: 16, weight: .bold)).foregroundStyle(color)
                .frame(maxWidth: .infinity, minHeight: 48)
                .background(RoundedRectangle(cornerRadius: 14).fill(bg))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(color, lineWidth: 1.5))
        }.buttonStyle(.plain)
    }
}
