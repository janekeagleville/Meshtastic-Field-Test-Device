import Foundation
import SwiftUI

enum Quality {
    case none, good, fair, bad
    var text: String { switch self { case .good: "READABLE"; case .fair: "MARGINAL"; case .bad: "UNREADABLE"; case .none: "NO DATA" } }
    var color: Color { switch self { case .good: Theme.green; case .fair: Theme.amber; case .bad: Theme.red; case .none: Theme.grey } }
    var bg: Color { switch self { case .good: Theme.okBg; case .fair: Theme.warnBg; case .bad: Theme.badBg; case .none: Theme.panel } }
}

struct NodeStat: Identifiable {
    var id: UInt32
    var name = ""
    var last = Date()
    var count = 0
    var rssi = 0
    var snr: Float = 0
    var lo = 0, hi = 0
    var sum = 0.0
    var hist: [Int] = []
    var hops: Int? = nil
    var mqtt = false

    var idText: String { String(format: "!%08x", id) }
    var title: String { name.isEmpty ? idText : name }
    var average: Double { count ? sum / Double(count) : 0 }
    var quality: Quality {
        if count == 0 { return .none }
        if snr >= Cfg.snrGood && rssi >= Cfg.rssiGood { return .good }
        if snr >= Cfg.snrFair && rssi >= Cfg.rssiFair { return .fair }
        return .bad
    }
    mutating func add(rssi r: Int, snr s: Float, hops h: Int?, mqtt m: Bool) {
        last = Date(); rssi = r; snr = s; hops = h; mqtt = m
        if count == 0 { lo = r; hi = r }
        lo = min(lo, r); hi = max(hi, r); count += 1; sum += Double(r)
        hist.append(r); if hist.count > Cfg.history { hist.removeFirst(hist.count - Cfg.history) }
    }
}

struct ProbeState {
    var on = true, pending = false
    var node: UInt32 = 0, id: UInt32 = 0
    var sentAt = Date.distantPast, nextAt = Date()
    var ok = 0, lost = 0, seq = 0
    var rtt: TimeInterval? = nil
}
