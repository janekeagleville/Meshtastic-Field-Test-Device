import Foundation
import CoreBluetooth
import CoreLocation

struct Found: Identifiable { let id: UUID; let name: String; var rssi: Int; let peripheral: CBPeripheral }

enum LinkState: Equatable { case idle, scanning, connecting, discovering, configuring, ready }

final class Tester: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate, CLLocationManagerDelegate {
    // MARK: UI state
    @Published var link: LinkState = .idle
    @Published var found: [Found] = []
    @Published var nodes: [UInt32: NodeStat] = [:]
    @Published var deviceName = ""
    @Published var myId: UInt32 = 0
    @Published var probe = ProbeState()
    @Published var logging = false
    @Published var written = 0
    @Published var logName = ""
    @Published var message = ""
    @Published var frames = 0, parseErrors = 0
    @Published var now = Date()
    @Published var bluetoothState: CBManagerState = .unknown

    @Published var colonInName: Bool { didSet { UserDefaults.standard.set(colonInName, forKey: "colon") } }

    // MARK: BLE
    private var central: CBCentralManager!
    private var periph: CBPeripheral?
    private var toRadio: CBCharacteristic?, fromRadio: CBCharacteristic?, fromNum: CBCharacteristic?
    private var draining = false
    private var configId: UInt32 = 0
    private var configured = false
    private var lastFrame = Date.distantPast, lastRequest = Date.distantPast, lastHeartbeat = Date.distantPast
    private var wantConnected = false
    private var timer: Timer?

    // MARK: clock / positions
    private var nodeLat: Double?, nodeLon: Double?
    private let loc = CLLocationManager()
    private var phone: CLLocation?

    // MARK: log file
    private var handle: FileHandle?
    private(set) var logURL: URL?
    private var logNode: UInt32 = 0

    override init() {
        colonInName = UserDefaults.standard.object(forKey: "colon") as? Bool ?? true
        super.init()
        central = CBCentralManager(delegate: self, queue: .main, options: [CBCentralManagerOptionRestoreIdentifierKey: "fieldtest"])
        loc.delegate = self
        loc.desiredAccuracy = kCLLocationAccuracyBest
        loc.allowsBackgroundLocationUpdates = true
        loc.pausesLocationUpdatesAutomatically = false
        loc.requestWhenInUseAuthorization()
        loc.startUpdatingLocation()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.tick() }
    }

    var sorted: [NodeStat] { nodes.values.filter { $0.count > 0 }.sorted { $0.last > $1.last } }
    var alive: Bool { link == .ready && now.timeIntervalSince(lastFrame) < 90 }

    // MARK: connection
    func scan() {
        guard central.state == .poweredOn else { return }
        found = []; link = .scanning; wantConnected = false
        central.scanForPeripherals(withServices: [CBUUID(string: Cfg.svc)], options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
    }
    func connect(_ f: Found) {
        central.stopScan()
        periph = f.peripheral; deviceName = f.name; wantConnected = true
        UserDefaults.standard.set(f.id.uuidString, forKey: "last")
        link = .connecting
        central.connect(f.peripheral, options: nil)
    }
    func disconnect() {
        wantConnected = false
        if let p = periph { central.cancelPeripheralConnection(p) }
        central.stopScan(); link = .idle; configured = false
    }
    private func reconnectLast() {
        guard central.state == .poweredOn else { return }
        if let s = UserDefaults.standard.string(forKey: "last"), let u = UUID(uuidString: s),
           let p = central.retrievePeripherals(withIdentifiers: [u]).first {
            periph = p; deviceName = p.name ?? deviceName; wantConnected = true; link = .connecting
            central.connect(p, options: nil)
        } else { scan() }
    }

    func centralManagerDidUpdateState(_ c: CBCentralManager) {
        bluetoothState = c.state
        if c.state == .poweredOn, link == .idle { reconnectLast() }
    }
    func centralManager(_ c: CBCentralManager, willRestoreState dict: [String: Any]) {
        if let p = (dict[CBCentralManagerRestoredStatePeripheralsKey] as? [CBPeripheral])?.first { periph = p; wantConnected = true }
    }
    func centralManager(_ c: CBCentralManager, didDiscover p: CBPeripheral, advertisementData: [String: Any], rssi: NSNumber) {
        let name = p.name ?? (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? "Meshtastic"
        if let i = found.firstIndex(where: { $0.id == p.identifier }) { found[i].rssi = rssi.intValue }
        else { found.append(Found(id: p.identifier, name: name, rssi: rssi.intValue, peripheral: p)) }
        // auto-connect to the last used device
        if UserDefaults.standard.string(forKey: "last") == p.identifier.uuidString, link == .scanning, found.count == 1 {
            connect(found[0])
        }
    }
    func centralManager(_ c: CBCentralManager, didConnect p: CBPeripheral) {
        link = .discovering; p.delegate = self
        p.discoverServices([CBUUID(string: Cfg.svc)])
    }
    func centralManager(_ c: CBCentralManager, didFailToConnect p: CBPeripheral, error: Error?) {
        message = "Connection failed"; link = .idle
        retryLater()
    }
    func centralManager(_ c: CBCentralManager, didDisconnectPeripheral p: CBPeripheral, error: Error?) {
        configured = false; draining = false
        if wantConnected { link = .connecting; message = "Disconnected – reconnecting"; retryLater() } else { link = .idle }
    }
    private func retryLater() {
        guard wantConnected, let p = periph else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            guard let self, self.wantConnected, self.central.state == .poweredOn else { return }
            self.link = .connecting; self.central.connect(p, options: nil)
        }
    }

    func peripheral(_ p: CBPeripheral, didDiscoverServices error: Error?) {
        guard let s = p.services?.first(where: { $0.uuid == CBUUID(string: Cfg.svc) }) else { message = "Meshtastic service not found"; return }
        p.discoverCharacteristics([CBUUID(string: Cfg.toRadio), CBUUID(string: Cfg.fromRadio), CBUUID(string: Cfg.fromNum)], for: s)
    }
    func peripheral(_ p: CBPeripheral, didDiscoverCharacteristicsFor s: CBService, error: Error?) {
        for c in s.characteristics ?? [] {
            switch c.uuid.uuidString.uppercased() {
            case Cfg.toRadio: toRadio = c
            case Cfg.fromRadio: fromRadio = c
            case Cfg.fromNum: fromNum = c
            default: break
            }
        }
        guard toRadio != nil, fromRadio != nil, let fn = fromNum else { message = "Characteristics not found"; return }
        p.setNotifyValue(true, for: fn)
        link = .configuring
        requestConfig()
    }
    func peripheral(_ p: CBPeripheral, didUpdateValueFor c: CBCharacteristic, error: Error?) {
        if let e = error as? CBATTError, e.code == .insufficientAuthentication || e.code == .insufficientEncryption {
            message = "Pairing required: enter the PIN shown on the node screen"; return
        }
        if error != nil { draining = false; return }
        if c.uuid == CBUUID(string: Cfg.fromNum) { drain(); return }
        if c.uuid == CBUUID(string: Cfg.fromRadio) {
            guard let d = c.value, !d.isEmpty else { draining = false; return }
            handleFromRadio([UInt8](d))
            p.readValue(for: c)   // keep reading until an empty response
        }
    }
    private func drain() {
        guard !draining, let p = periph, let c = fromRadio else { return }
        draining = true; p.readValue(for: c)
    }
    private func send(_ bytes: [UInt8]) {
        guard let p = periph, let c = toRadio else { return }
        p.writeValue(Data(bytes), for: c, type: .withResponse)
    }
    func peripheral(_ p: CBPeripheral, didWriteValueFor c: CBCharacteristic, error: Error?) {
        if let e = error as? CBATTError, e.code == .insufficientAuthentication || e.code == .insufficientEncryption {
            message = "Pairing required: enter the PIN shown on the node screen"
        }
        drain()
    }
    private func requestConfig() {
        configId = UInt32.random(in: 1...UInt32.max); configured = false
        send(Mesh.wantConfig(configId)); lastRequest = Date()
    }

    // MARK: FromRadio
    private func handleFromRadio(_ d: [UInt8]) {
        var chk = PBReader(d); while chk.next() != nil {}
        if !chk.good { parseErrors += 1; return }
        lastFrame = Date(); frames += 1
        var r = PBReader(d)
        while let f = r.next() {
            switch (f.tag, f.wire) {
            case (2, 2): handlePacket(f.bytes)
            case (3, 2):
                var i = PBReader(f.bytes)
                while let a = i.next() { if a.tag == 1 && a.wire == 0 && a.value != 0 { myId = UInt32(truncatingIfNeeded: a.value) } }
            case (4, 2): handleNodeInfo(f.bytes)
            case (7, 0): if UInt32(truncatingIfNeeded: f.value) == configId { configured = true; link = .ready; message = "" }
            case (8, 0): if f.value != 0 { configured = false; nodeLat = nil; nodeLon = nil; lastRequest = .distantPast }
            default: break
            }
        }
    }
    private func updateName(_ id: UInt32, _ u: Mesh.UserInfo) {
        var n = nodes[id] ?? NodeStat(id: id)
        let nm = !u.longName.isEmpty ? u.longName : u.shortName
        if !nm.isEmpty { n.name = nm }
        if nodes[id] == nil { n.count = 0 }
        nodes[id] = n
    }
    private func handleNodeInfo(_ d: [UInt8]) {
        var r = PBReader(d); var id: UInt32 = 0; var user: [UInt8]?; var pos: [UInt8]?
        while let f = r.next() {
            if f.tag == 1 && f.wire == 0 { id = UInt32(truncatingIfNeeded: f.value) }
            if f.tag == 2 && f.wire == 2 { user = f.bytes }
            if f.tag == 3 && f.wire == 2 { pos = f.bytes }
        }
        guard r.good, id != 0 else { if !r.good { parseErrors += 1 }; return }
        if let u = user, let ui = Mesh.parseUser(u) { updateName(id, ui) }
        else if nodes[id] == nil { nodes[id] = NodeStat(id: id, count: 0) }
        if id == myId, let p = pos, let q = Mesh.parsePosition(p) { nodeLat = q.lat; nodeLon = q.lon }
    }

    private func handlePacket(_ d: [UInt8]) {
        guard let m = Mesh.parsePacket(d) else { parseErrors += 1; return }
        var rtt: TimeInterval? = nil
        if m.from == myId {
            if m.port == 3, let q = Mesh.parsePosition(m.payload) { nodeLat = q.lat; nodeLon = q.lon }
            if m.port == 5, probe.pending, m.requestId == probe.id, let rt = Mesh.parseRouting(m.payload), rt.isAck, rt.err != 0 { probeLost() }
            return
        }
        if m.port == 5, probe.pending, m.from == probe.node, m.requestId == probe.id, let rt = Mesh.parseRouting(m.payload), rt.isAck {
            if rt.err == 0 {
                let t = Date().timeIntervalSince(probe.sentAt); rtt = t
                probe.rtt = t; probe.ok += 1; probe.pending = false
                probe.nextAt = max(probe.sentAt.addingTimeInterval(Cfg.probeInterval), Date().addingTimeInterval(2))
            } else { probeLost() }
        }
        if m.port == 4, let u = Mesh.parseUser(m.payload) { updateName(m.from, u) }
        // Ignore packets without RSSI, MQTT-originated and own packets.
        guard m.hasRssi, !m.mqtt, m.transport <= 4, m.from != 0, m.snr.isFinite, m.rssi >= -200, m.rssi <= 20 else { return }
        var n = nodes[m.from] ?? NodeStat(id: m.from)
        let hops: Int? = (m.hasHopStart && m.hopStart > 0 && m.hopStart >= m.hopLimit) ? m.hopStart - m.hopLimit : nil
        n.add(rssi: m.rssi, snr: m.snr, hops: hops, mqtt: m.mqtt)
        nodes[m.from] = n
        logPacket(m, n, rtt)
    }

    // MARK: link probing
    func probeStart(_ id: UInt32) { probe = ProbeState(node: id) }
    func probeStop() { probe = ProbeState(on: false) }
    func toggleProbe() { probe.on.toggle(); if probe.on { probe.nextAt = Date() } }
    private func probeLost() {
        probe.pending = false; probe.lost += 1
        probe.nextAt = max(probe.sentAt.addingTimeInterval(Cfg.probeInterval), Date().addingTimeInterval(2))
    }
    private func tick() {
        now = Date()
        guard link == .ready || link == .configuring else { return }
        if link == .configuring, now.timeIntervalSince(lastRequest) > 20 { requestConfig() }
        if configured, now.timeIntervalSince(lastHeartbeat) > 30 { send(Mesh.heartbeat); lastHeartbeat = now }
        if probe.node != 0 {
            if probe.pending, now.timeIntervalSince(probe.sentAt) > Cfg.probeTimeout { probeLost() }
            if probe.on, configured, !probe.pending, now >= probe.nextAt {
                let id = UInt32.random(in: 1...UInt32.max)
                send(Mesh.buildProbe(to: probe.node, id: id, seq: UInt16(truncatingIfNeeded: probe.seq), port: Cfg.probePort, channel: Cfg.probeChannel, hopLimit: Cfg.probeHopLimit))
                probe.id = id; probe.sentAt = now; probe.pending = true; probe.seq += 1
            }
        }
    }

    // MARK: phone location
    func locationManager(_ m: CLLocationManager, didUpdateLocations l: [CLLocation]) { phone = l.last }

    // MARK: logging
    static var docs: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }

    func toggleLog(node: UInt32?) { logging ? stopLog() : startLog(node ?? 0) }
    func stopLog() { try? handle?.synchronize(); try? handle?.close(); handle = nil; logging = false }
    private func startLog(_ id: UInt32) {
        let base = id == 0 ? "ALL" : LogNaming.safe(nodes[id]?.title ?? String(format: "!%08x", id))
        let stem = "\(base.isEmpty ? String(format: "!%08x", id) : base)_\(LogNaming.stamp(Date(), colon: colonInName))"
        var url = Tester.docs.appendingPathComponent(stem + ".csv")
        var k = 2
        while FileManager.default.fileExists(atPath: url.path) { url = Tester.docs.appendingPathComponent("\(stem)-\(k).csv"); k += 1 }
        guard FileManager.default.createFile(atPath: url.path, contents: nil), let h = try? FileHandle(forWritingTo: url) else {
            flash("LOG WRITE ERROR"); return
        }
        let head = "time_local,rx_epoch,sender_id,sender_name,packet_id,rssi_dbm,snr_db,hops,relay_low_byte,via_mqtt,transport,node_lat,node_lon,phone_lat,phone_lon,phone_acc_m,probe_rtt_ms\n"
        h.write(Data(head.utf8))
        handle = h; logURL = url; logName = url.lastPathComponent; logging = true; logNode = id; written = 0
    }
    private func logPacket(_ m: Mesh.Packet, _ n: NodeStat, _ rtt: TimeInterval?) {
        guard logging, let h = handle else { return }
        if logNode != 0 && m.from != logNode { return }
        let f = DateFormatter(); f.timeZone = LogNaming.warsaw; f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        func num(_ v: Double?, _ fmt: String) -> String { v.map { String(format: fmt, $0) } ?? "" }
        let name = n.name.replacingOccurrences(of: "\"", with: "\"\"")
        let row = [f.string(from: Date()), "\(m.epoch)", String(format: "%08x", m.from), "\"\(name)\"", String(format: "%08x", m.id),
                   "\(m.rssi)", String(format: "%.2f", m.snr), n.hops.map(String.init) ?? "", "\(m.relay)", m.mqtt ? "1" : "0", "\(m.transport)",
                   num(nodeLat, "%.7f"), num(nodeLon, "%.7f"), num(phone?.coordinate.latitude, "%.7f"), num(phone?.coordinate.longitude, "%.7f"),
                   num(phone?.horizontalAccuracy, "%.0f"), rtt.map { String(Int($0 * 1000)) } ?? ""].joined(separator: ",") + "\n"
        do { try h.write(contentsOf: Data(row.utf8)); written += 1 } catch { stopLog(); flash("LOG WRITE ERROR") }
    }
    func flash(_ s: String) {
        message = s
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [weak self] in if self?.message == s { self?.message = "" } }
    }
}
