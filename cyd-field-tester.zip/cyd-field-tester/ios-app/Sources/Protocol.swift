import Foundation

/// Minimal protobuf reader/writer (same Meshtastic fields as the CYD firmware, no external libraries).
struct PBField {
    var tag: Int
    var wire: Int
    var value: UInt64 = 0
    var bytes: [UInt8] = []
}

struct PBReader {
    private let b: [UInt8]
    private var i = 0
    private(set) var good = true
    init(_ bytes: [UInt8]) { b = bytes }

    private mutating func varint() -> UInt64? {
        var v: UInt64 = 0
        for k in 0..<10 {
            guard i < b.count else { good = false; return nil }
            let x = b[i]; i += 1
            if k == 9 && x > 1 { good = false; return nil }
            v |= UInt64(x & 127) << UInt64(7 * k)
            if x & 128 == 0 { return v }
        }
        good = false; return nil
    }

    mutating func next() -> PBField? {
        guard good, i < b.count, let key = varint() else { return nil }
        let tag = Int(key >> 3), wire = Int(key & 7)
        guard tag > 0, tag <= 0x1fffffff else { good = false; return nil }
        var f = PBField(tag: tag, wire: wire)
        switch wire {
        case 0:
            guard let v = varint() else { return nil }
            f.value = v
        case 1, 5:
            let n = wire == 1 ? 8 : 4
            guard b.count - i >= n else { good = false; return nil }
            for k in 0..<n { f.value |= UInt64(b[i + k]) << UInt64(8 * k) }
            i += n
        case 2:
            guard let len = varint(), len <= UInt64(b.count - i) else { good = false; return nil }
            f.bytes = Array(b[i..<(i + Int(len))]); i += Int(len)
        default:
            good = false; return nil
        }
        return f
    }
}

struct PBWriter {
    var out: [UInt8] = []
    mutating func varint(_ v: UInt64) {
        var x = v
        repeat { out.append(UInt8(x & 127) | (x > 127 ? 128 : 0)); x >>= 7 } while x != 0
    }
    mutating func uint(_ tag: Int, _ v: UInt64) { varint(UInt64(tag << 3)); varint(v) }
    mutating func fixed32(_ tag: Int, _ v: UInt32) {
        varint(UInt64(tag << 3 | 5))
        for k in 0..<4 { out.append(UInt8((v >> UInt32(8 * k)) & 0xff)) }
    }
    mutating func bytes(_ tag: Int, _ d: [UInt8]) { varint(UInt64(tag << 3 | 2)); varint(UInt64(d.count)); out += d }
}

enum Mesh {
    struct Packet {
        var from: UInt32 = 0, to: UInt32 = 0, id: UInt32 = 0, requestId: UInt32 = 0, epoch: UInt32 = 0
        var rssi: Int = 0
        var snr: Float = 0
        var hopStart = 0, hopLimit = 0, relay = 0, port = 0, transport = 0
        var hasRssi = false, hasSnr = false, hasHopStart = false, mqtt = false
        var payload: [UInt8] = []
    }

    struct UserInfo { var longName = ""; var shortName = "" }

    static func parsePacket(_ data: [UInt8]) -> Packet? {
        var r = PBReader(data); var p = Packet()
        while let f = r.next() {
            switch (f.tag, f.wire) {
            case (1, 5): p.from = UInt32(truncatingIfNeeded: f.value)
            case (2, 5): p.to = UInt32(truncatingIfNeeded: f.value)
            case (6, 5): p.id = UInt32(truncatingIfNeeded: f.value)
            case (7, 5): p.epoch = UInt32(truncatingIfNeeded: f.value)
            case (8, 5): p.snr = Float(bitPattern: UInt32(truncatingIfNeeded: f.value)); p.hasSnr = true
            case (12, 0): p.rssi = Int(Int32(truncatingIfNeeded: f.value)); p.hasRssi = true
            case (9, 0): p.hopLimit = Int(f.value)
            case (15, 0): p.hopStart = Int(f.value); p.hasHopStart = true
            case (14, 0): p.mqtt = f.value != 0
            case (19, 0): p.relay = Int(f.value)
            case (21, 0): p.transport = Int(f.value)
            case (4, 2):
                var d = PBReader(f.bytes)
                while let a = d.next() {
                    if a.tag == 1 && a.wire == 0 { p.port = Int(a.value) }
                    if a.tag == 2 && a.wire == 2 { p.payload = a.bytes }
                    if a.tag == 6 && a.wire == 5 { p.requestId = UInt32(truncatingIfNeeded: a.value) }
                }
                if !d.good { return nil }
            default: break
            }
        }
        return r.good ? p : nil
    }

    static func parseUser(_ data: [UInt8]) -> UserInfo? {
        var r = PBReader(data); var u = UserInfo()
        while let f = r.next() {
            if f.tag == 2 && f.wire == 2 { u.longName = String(decoding: f.bytes, as: UTF8.self) }
            if f.tag == 3 && f.wire == 2 { u.shortName = String(decoding: f.bytes, as: UTF8.self) }
        }
        return r.good ? u : nil
    }

    /// Position: lat/lon w 1e-7 stopnia.
    static func parsePosition(_ data: [UInt8]) -> (lat: Double, lon: Double, epoch: UInt32)? {
        var r = PBReader(data); var lat: Int32?, lon: Int32?; var epoch: UInt32 = 0
        while let f = r.next() {
            if f.tag == 1 && f.wire == 5 { lat = Int32(truncatingIfNeeded: f.value) }
            if f.tag == 2 && f.wire == 5 { lon = Int32(truncatingIfNeeded: f.value) }
            if (f.tag == 4 || f.tag == 7) && f.wire == 5 && f.value != 0 { epoch = UInt32(truncatingIfNeeded: f.value) }
        }
        guard r.good, let la = lat, let lo = lon, abs(la) <= 900_000_000, abs(lo) <= 1_800_000_000 else { return nil }
        return (Double(la) * 1e-7, Double(lo) * 1e-7, epoch)
    }

    /// Routing: (isAck, error). err 0 = ACK.
    static func parseRouting(_ data: [UInt8]) -> (isAck: Bool, err: Int)? {
        var r = PBReader(data); var err = 0; var ack = true
        while let f = r.next() {
            if f.tag == 3 && f.wire == 0 { err = Int(f.value) }
            if (f.tag == 1 || f.tag == 2) && f.wire == 2 { ack = false }
        }
        return r.good ? (ack, err) : nil
    }

    /// ToRadio{want_config_id}
    static func wantConfig(_ id: UInt32) -> [UInt8] { var w = PBWriter(); w.uint(3, UInt64(id)); return w.out }
    /// ToRadio{heartbeat}
    static let heartbeat: [UInt8] = [0x3a, 0x00]

    /// ToRadio{packet=MeshPacket{to, channel, decoded=Data{port, "MZ"+seq}, id, want_ack}}
    static func buildProbe(to: UInt32, id: UInt32, seq: UInt16, port: Int, channel: Int, hopLimit: Int) -> [UInt8] {
        var d = PBWriter()
        d.uint(1, UInt64(port)); d.bytes(2, [0x4d, 0x5a, UInt8(seq >> 8), UInt8(seq & 0xff)])
        var m = PBWriter()
        m.fixed32(2, to)
        if channel > 0 && channel < 8 { m.uint(3, UInt64(channel)) }
        m.bytes(4, d.out)
        m.fixed32(6, id)
        if hopLimit > 0 && hopLimit < 8 { m.uint(9, UInt64(hopLimit)) }
        m.uint(10, 1)
        var t = PBWriter(); t.bytes(1, m.out); return t.out
    }
}

/// Log file names: "<node name>_DDMMYY_HH:MM:SS" in Polish local time (Europe/Warsaw).
enum LogNaming {
    static let warsaw = TimeZone(identifier: "Europe/Warsaw") ?? .current
    static func stamp(_ date: Date, colon: Bool) -> String {
        let f = DateFormatter()
        f.timeZone = warsaw; f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = colon ? "ddMMyy_HH:mm:ss" : "ddMMyy_HH-mm-ss"
        return f.string(from: date)
    }
    /// Keeps letters (including diacritics), digits and "-._!"; everything else becomes "_".
    static func safe(_ s: String) -> String {
        var out = ""; var us = true
        for ch in s {
            if ch.isLetter || ch.isNumber || "-.!".contains(ch) { out.append(ch); us = false }
            else if !us { out.append("_"); us = true }
        }
        while let l = out.last, l == "_" || l == "." { out.removeLast() }
        return String(out.prefix(60))
    }
}
