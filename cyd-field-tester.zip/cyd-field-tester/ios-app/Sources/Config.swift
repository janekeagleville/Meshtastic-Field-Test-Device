import SwiftUI

enum Cfg {
    // Gauge scales and readability thresholds — same as the CYD firmware (config.h).
    static let gaugeMin = -130, gaugeMax = -30
    static let snrMin: Float = -20, snrMax: Float = 15
    static let hopMax = 7
    static let snrGood: Float = -5, snrFair: Float = -15
    static let rssiGood = -115, rssiFair = -125
    static let history = 48
    // Active link probe: direct packet on a private port with want_ack (each probe is a LoRa transmission).
    static let probeInterval: TimeInterval = 15, probeTimeout: TimeInterval = 25
    static let probePort = 256, probeChannel = 0, probeHopLimit = 0
    // Meshtastic BLE service and characteristic UUIDs
    static let svc = "6BA1B218-15A8-461F-9FA8-5DCAE273EAFD"
    static let toRadio = "F75C76D2-129E-4DAD-A1DD-7866124401E7"
    static let fromRadio = "2C55E69E-4993-11ED-B878-0242AC120002"
    static let fromNum = "ED9DA18C-A800-4F66-A670-AA7547E34453"
}

/// Palette matching the CYD screen (dark green + turquoise).
enum Theme {
    static func rgb(_ r: Double, _ g: Double, _ b: Double) -> Color { Color(red: r / 255, green: g / 255, blue: b / 255) }
    static let bg = rgb(0, 34, 22), hdr = rgb(0, 18, 12), panel = rgb(6, 56, 40), line = rgb(30, 170, 120)
    static let turq = rgb(0, 255, 224), green = rgb(30, 255, 120), amber = rgb(255, 190, 0), red = rgb(255, 56, 44)
    static let dim = rgb(140, 230, 200), okBg = rgb(4, 78, 46), warnBg = rgb(80, 54, 0), badBg = rgb(86, 14, 10)
    static let grey = rgb(170, 190, 182), track = rgb(10, 80, 58)
    static let gradient = Gradient(stops: [
        .init(color: red, location: 0), .init(color: amber, location: 0.33),
        .init(color: green, location: 0.66), .init(color: turq, location: 1)])
}
