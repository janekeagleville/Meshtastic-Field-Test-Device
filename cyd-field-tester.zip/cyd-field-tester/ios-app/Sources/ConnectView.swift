import SwiftUI

struct ConnectView: View {
    @ObservedObject var t: Tester
    @Binding var show: Bool

    var body: some View {
        NavigationStack {
            List {
                Section("Connection") {
                    HStack { Text("Status"); Spacer(); Text(stateText).foregroundStyle(Theme.turq) }
                    if t.link != .idle {
                        Button("Disconnect", role: .destructive) { t.disconnect() }
                    }
                    Button(t.link == .scanning ? "Scanning…" : "Scan for nodes") { t.scan() }
                }
                Section("Discovered Meshtastic nodes") {
                    if t.found.isEmpty { Text("None found. Enable Bluetooth on the node and disconnect other BLE clients.").foregroundStyle(.secondary) }
                    ForEach(t.found) { f in
                        Button { t.connect(f); show = false } label: {
                            HStack { Text(f.name); Spacer(); Text("\(f.rssi) dBm").foregroundStyle(.secondary) }
                        }
                    }
                }
                Section("Logging") {
                    Toggle("Colons in file name (HH:MM:SS)", isOn: $t.colonInName)
                    Text("File name: <node name>_DDMMYY_HH:MM:SS.csv. Turn colons off if the files will be copied to Windows or a FAT volume.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Tips") {
                    Text("Bluetooth must be enabled on the node. The pairing PIN is shown on its screen (T-Echo) or defaults to 123456. The official Meshtastic app must not be connected at the same time.")
                        .font(.footnote)
                }
            }
            .navigationTitle("BLE node").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { show = false } } }
            .onAppear { if t.link == .idle { t.scan() } }
        }.preferredColorScheme(.dark)
    }

    private var stateText: String {
        switch t.link {
        case .idle: "disconnected"; case .scanning: "scanning"; case .connecting: "connecting"
        case .discovering: "discovering services"; case .configuring: "configuring"; case .ready: "ready"
        }
    }
}

struct LogsView: View {
    @ObservedObject var t: Tester
    @Environment(\.dismiss) private var dismiss
    @State private var files: [URL] = []

    var body: some View {
        NavigationStack {
            List {
                if files.isEmpty { Text("No logs yet. Select a node and tap LOG.").foregroundStyle(.secondary) }
                ForEach(files, id: \.self) { u in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(u.lastPathComponent).font(.system(size: 14, weight: .semibold)).lineLimit(2)
                            Text(size(u)).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                    }
                }.onDelete { idx in
                    for i in idx { if files[i] != t.logURL || !t.logging { try? FileManager.default.removeItem(at: files[i]) } }
                    reload()
                }
            }
            .navigationTitle("CSV logs").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
            .onAppear(perform: reload)
        }.preferredColorScheme(.dark)
    }

    private func reload() {
        let all = (try? FileManager.default.contentsOfDirectory(at: Tester.docs, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        files = all.filter { $0.pathExtension == "csv" }.sorted {
            ((try? $0.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast) >
            ((try? $1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast)
        }
    }
    private func size(_ u: URL) -> String {
        let b = (try? u.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        return ByteCountFormatter.string(fromByteCount: Int64(b), countStyle: .file)
    }
}
