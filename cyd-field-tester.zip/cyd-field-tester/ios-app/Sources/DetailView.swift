import SwiftUI
import Charts

struct DetailView: View {
    @ObservedObject var t: Tester
    let id: UInt32

    var body: some View {
        if let n = t.nodes[id] {
            ScrollView {
                VStack(spacing: 10) {
                    Panel {
                        HStack {
                            Caption("NODE")
                            Text(n.title).font(.system(size: 18, weight: .bold)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.6)
                            Spacer()
                            Text(n.idText).font(.system(size: 15, design: .monospaced)).foregroundStyle(Theme.turq)
                        }
                    }
                    Panel {
                        VStack(spacing: 6) {
                            HStack {
                                Circle().fill(dotColor).frame(width: 9, height: 9)
                                Caption("RSSI")
                                Spacer()
                                QualityChip(q: n.quality)
                            }
                            Gauge(rssi: n.rssi).frame(height: 150)
                        }
                    }.onTapGesture { t.toggleProbe() }
                    HStack(spacing: 10) {
                        Panel {
                            VStack(alignment: .leading, spacing: 6) {
                                Caption("SNR")
                                HStack(alignment: .firstTextBaseline) {
                                    Text(String(format: "%.1f", n.snr)).font(.system(size: 30, weight: .bold, design: .rounded)).foregroundStyle(snrColor(n.snr))
                                    Text("dB").foregroundStyle(Theme.dim)
                                }
                                BarMeter(fraction: Double((n.snr - Cfg.snrMin) / (Cfg.snrMax - Cfg.snrMin)), color: snrColor(n.snr))
                            }
                        }
                        Panel {
                            VStack(alignment: .leading, spacing: 8) {
                                Caption("HOPS")
                                Text(hopText(n.hops)).font(.system(size: 20, weight: .bold)).foregroundStyle(.white)
                                HopDots(hops: n.hops)
                            }
                        }
                    }
                    HStack(spacing: 8) {
                        stat("N", "\(n.count)"); stat("MIN dBm", "\(n.lo)"); stat("MAX dBm", "\(n.hi)"); stat("AVG dBm", String(format: "%.1f", n.average))
                    }
                    Panel {
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Caption("RSSI dBm, LAST \(n.hist.count)")
                                Spacer()
                                if t.probe.node == id {
                                    let tot = t.probe.ok + t.probe.lost
                                    Text("\(t.probe.on ? "TEST" : "PAUSED") \(t.probe.ok)/\(tot)" + (t.probe.rtt.map { String(format: " RTT %.1fs", $0) } ?? ""))
                                        .font(.system(size: 12, weight: .semibold))
                                        .foregroundStyle(t.probe.lost > 0 && t.probe.lost * 4 > tot ? Theme.amber : Theme.turq)
                                }
                            }
                            Chart {
                                RuleMark(y: .value("threshold", Cfg.rssiGood)).foregroundStyle(Theme.line.opacity(0.6)).lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 3]))
                                ForEach(Array(n.hist.enumerated()), id: \.offset) { i, v in
                                    LineMark(x: .value("#", i), y: .value("RSSI", v)).foregroundStyle(Theme.turq).interpolationMethod(.monotone)
                                }
                            }
                            .chartYScale(domain: Cfg.gaugeMin...Cfg.gaugeMax)
                            .chartYAxisLabel("dBm")
                            .chartXScale(domain: 0...(Cfg.history - 1))
                            .chartXAxis(.hidden)
                            .chartYAxis { AxisMarks(values: [-120, -100, -80, -60, -40]) { _ in AxisValueLabel().foregroundStyle(Theme.dim); AxisGridLine().foregroundStyle(Theme.track) } }
                            .frame(height: 120)
                        }
                    }
                }.padding(.horizontal, 16).padding(.top, 8)
            }
            .onAppear { t.probeStart(id) }
            .onDisappear { t.probeStop() }
        } else { Spacer() }
    }

    private var dotColor: Color {
        guard t.probe.node == id, t.probe.on else { return Theme.grey }
        return t.probe.pending ? Theme.amber : Theme.turq
    }
    private func snrColor(_ s: Float) -> Color { s >= Cfg.snrGood ? Theme.turq : s >= Cfg.snrFair ? Theme.amber : Theme.red }
    private func hopText(_ h: Int?) -> String { h == nil ? "?" : h == 0 ? "DIRECT" : "\(min(h!, Cfg.hopMax))/\(Cfg.hopMax) hop" }
    private func stat(_ l: String, _ v: String) -> some View {
        Panel { VStack(spacing: 2) { Caption(l); Text(v).font(.system(size: 18, weight: .bold)).foregroundStyle(.white) }.frame(maxWidth: .infinity) }
    }
}
