# Field Test Kit (iPhone) — odpowiednik aplikacji CYD

Aplikacja SwiftUI (iOS 17+, iPhone 16 Pro) łączy się przez **Bluetooth LE** z węzłem Meshtastic (np. LilyGo T-Echo)
i robi to samo co CYD: lista nodów (RSSI/SNR/wiek), ekran pracy z wskaźnikiem RSSI, SNR, hopami, statystykami N/MIN/MAX/ŚR.,
wykresem ostatnich 48 odczytów i werdyktem **CZYTELNY / GRANICZNY / NIECZYTELNY** (te same progi co w `config.h`),
aktywne sondowanie łącza (pakiet na port 256 z żądaniem ACK, co 15 s) oraz zapis CSV klawiszem **LOG**.

## Uruchomienie (Mac z Xcode 15+)
1. `brew install xcodegen`, potem w tym folderze: `xcodegen generate` → powstaje `FieldTestKit.xcodeproj`.
   (Bez XcodeGen: Xcode → New Project → iOS App (SwiftUI), usuń domyślne pliki, przeciągnij `Sources/*.swift`,
   w Signing & Capabilities dodaj Background Modes: *Uses Bluetooth LE accessories* i *Location updates*, a w Info.plist wpisy z `project.yml`.)
2. Wybierz swój zespół (Signing & Capabilities → Team), podłącz iPhone'a, Run. Na telefonie: Ustawienia → Prywatność → Tryb programisty.
3. W węźle: Bluetooth włączony; zamknij/rozłącz aplikację Meshtastic (BLE obsługuje jednego klienta).
4. Przy pierwszym połączeniu iOS poprosi o PIN: ekran T-Echo pokaże 6 cyfr (albo domyślny 123456).

## Obsługa
- Nagłówek (dotknięcie) → wybór węzła BLE. Ostatni węzeł łączy się automatycznie.
- Lista: dotknij node → ekran pracy (start sondowania). Dotknięcie wskaźnika RSSI włącza/pauzuje test.
- LOG (dół): na ekranie pracy zapisuje wybrany node, na liście — cały ruch (`ALL_…`). Pliki: `Nazwa-noda_DDMMYY_HH:MM:SS.csv`,
  czas polski. Dwukropek można wyłączyć w ustawieniach połączenia (przydatne dla Windows/FAT).
- FILES: lista plików, udostępnianie (AirDrop, Pliki). Pliki są też widoczne w aplikacji Pliki → Na moim iPhonie → Field Test Kit.
- CSV: `time_local, rx_epoch, sender_id, sender_name, packet_id, rssi_dbm, snr_db, hops, relay_low_byte, via_mqtt, transport, node_lat, node_lon, phone_lat, phone_lon, phone_acc_m, probe_rtt_ms`.
  Pozycja telefonu pochodzi z GPS iPhone'a; czas z zegara telefonu (brak problemu „BRAK-CZASU”).

## Uwagi
- RSSI/SNR to parametry pakietów odebranych przez **węzeł** (T-Echo), nie przez telefon.
- Praca w tle: aplikacja korzysta z trybów tła BLE i lokalizacji, więc test trwa przy zablokowanym ekranie (ikona lokalizacji w pasku stanu).
- Każde sondowanie to transmisja LoRa; interwał jest w `Config.swift` (`probeInterval`).
- Kod nie był kompilowany w środowisku, w którym powstał (brak Xcode); format pakietu sondy zweryfikowano bajt po bajcie z działającym kodem CYD.
